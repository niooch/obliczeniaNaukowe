module MyRoots

export newton, bisekcja, sieczne

include("newton.jl")
include("bisekcja.jl")
include("sieczne.jl")

end # module Roots
