#include <stdio.h>
#include <float.h>

int main(void) {
    printf("FLT_MAX   = %.17g\n", (double)FLT_MAX);
    printf("DBL_MAX   = %.17g\n", DBL_MAX);
    return 0;
}
